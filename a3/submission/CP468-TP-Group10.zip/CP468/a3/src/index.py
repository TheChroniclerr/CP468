"""Read-only global index
"""
index: dict = {}
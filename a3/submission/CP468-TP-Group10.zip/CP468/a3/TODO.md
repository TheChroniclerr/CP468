# TODO LIST

- [x] Implement SGA
- [x] Separate modules
- [x] Global/dynamic reimplementation
- [ ] UI control
- [x] Visualizaton (for other objfuncs) 
  - [x] logarithmatice heatmap
  - [x] point fix
- [x] Allow setting initial population range 
- [x] Stats
  - [x] Stats display
  - [x] Stats saving

# Features

- [x] 2's Complement (Deprecated)
- [x] Resolution tuning (objfunc)
- Visualization
  - [x] contour lines
  - [x] logarithmatic contour lines
- [ ] Fitness score adjust
- [ ] Reproduction implementation

# Others

- [ ] Functional discussion